let params = {
  // (add)
};

let room;
let objectGroup; // don't change this variable name. It is also used in script-webxr.js
let ceiling;
let WORLD_HALF = 10;
let ring1, ring2, ring3;

let petals = [];
let petalObj;

function setupThree() {
  loadOBJ("assets/petal.obj");


  const loader = new THREE.CubeTextureLoader();
  loader.setPath('assets/background/');
  textureCube = loader.load([
    'brick.png', 'brick.png',
    'ceiling.png', 'brick.png',
    'brick.png', 'brick.png'
  ]);
  scene.background = textureCube;

  ring2 = getRing(WORLD_HALF / 15, WORLD_HALF / 5);
  ring2.position.y = 0
  ring2.rotation.x = -PI / 2;

  ring3 = getRing(WORLD_HALF / 4, WORLD_HALF / 2);
  ring3.position.y = 0;
  ring3.rotation.x = -PI / 2;

  // renderer additional setup
  renderer.shadowMap.enabled = true;

  // WebXR
  setupWebXR();

  // socket.io
  setupSocket();

  // room
  room = getRoom();
  //scene.add(room);

  // floor
  const floorGeometry = new THREE.PlaneGeometry(6, 6);
  const floorMaterial = new THREE.ShadowMaterial({ opacity: 0.25, blending: THREE.CustomBlending, transparent: false });
  const floor = new THREE.Mesh(floorGeometry, floorMaterial);
  floor.rotation.x = - Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  // lights
  const hemiLight = new THREE.HemisphereLight(0xa5a5a5, 0x898989, 3);
  scene.add(hemiLight);

  const light = new THREE.DirectionalLight(0xffffff, 3);
  light.position.set(0, 6, 0);
  light.castShadow = true;
  light.shadow.camera.top = 3;
  light.shadow.camera.bottom = - 3;
  light.shadow.camera.right = 3;
  light.shadow.camera.left = - 3;
  light.shadow.mapSize.set(4096, 4096);
  scene.add(light);

  const spotLight = new THREE.SpotLight(0xCC0066, WORLD_HALF, WORLD_HALF * 2, PI / 2, 0.5, 0.1);
  spotLight.position.set(0, 10, 0);
  // spotLight.map = new THREE.TextureLoader().load(url);

  spotLight.castShadow = true;

  spotLight.shadow.mapSize.width = 1024;
  spotLight.shadow.mapSize.height = 1024;

  spotLight.shadow.camera.near = 500;
  spotLight.shadow.camera.far = 4000;
  spotLight.shadow.camera.fov = 30;

  scene.add(spotLight);

  // cubes
  objectGroup = new THREE.Group();
  scene.add(objectGroup);

  for (let angle = 0; angle < 360; angle += 30) {
    const object1 = getBox(1.2);

    object1.userData.id = angle / 30; // 0 - 11

    object1.position.x = cos(radians(angle)) * random(1.5, 2);
    object1.position.y = 1;
    object1.position.z = sin(radians(angle)) * random(1.5, 2);

    object1.rotation.x = random(TWO_PI);
    object1.rotation.y = random(TWO_PI);
    object1.rotation.z = random(TWO_PI);

    object1.scale.setScalar(random(0.2, 0.5));

    object1.castShadow = true;
    object1.receiveShadow = true;

    objectGroup.add(object1);
  }
  for (let angle = 0; angle < 360; angle += 45) {
    const object2 = getBox(2);

    object2.userData.id = 12 + angle / 45; // 0 - 7

    object2.position.x = cos(radians(angle)) * 2;
    object2.position.y = 7;
    object2.position.z = sin(radians(angle)) * 2;

    object2.rotation.x = random(TWO_PI);
    object2.rotation.y = random(TWO_PI);
    object2.rotation.z = random(TWO_PI);

    object2.scale.setScalar(random(0.5, 0.8));

    object2.castShadow = true;
    object2.receiveShadow = true;

    objectGroup.add(object2);
  }

  let adjustment = 45 / 2;
  for (let angle = 0 + adjustment; angle < 360 + adjustment; angle += 45) {
    const object3 = getBox(9);

    object3.userData.id = 20 + (angle - adjustment) / 45; // 

    object3.position.x = cos(radians(angle)) * 5.5;
    object3.position.y = 1.5;
    object3.position.z = sin(radians(angle)) * 5.5;



    object3.scale.setScalar(1, 3, 1);

    object3.castShadow = true;
    object3.receiveShadow = true;

    objectGroup.add(object3);
  }


  ceiling = getCeiling();
  scene.add(ceiling);
}

function updateThree() {

  ringUp(ring2);
  ringDown(ring3);

  // update the objects
  for (let p of petals) {
    p.move();
    p.rotate();
    p.update();
    p.age();
  }

  // // remove the cubes that are done
  for (let i = 0; i < petals.length; i++) {
    let p = petals[i];
    if (p.isDone) {
      scene.remove(p.mesh);
      petals.splice(i, 1);
      i--;
    }
  }

  if (volume) {
    for (let i = 0; i < objectGroup.children.length; i++) {
      let object = objectGroup.children[i];
      let size = map(volume, 0, 1, 0.3, 2);
      object.scale.set(size, size, size);
    }
  }

  // room.rotation.y += 0.001;

  cleanIntersected();
  intersectObjects(controller1);
  intersectObjects(controller2);



}

function ringUp(ring) {
  const dampingFactor = 0.05; // control the speed of the transition

  let posArray2 = ring.geometry.attributes.position.array;
  for (let i = 0; i < posArray2.length; i += 3) {
    let x2 = posArray2[i + 0];
    let y2 = posArray2[i + 1];

    let xOffset2 = (x2 + WORLD_HALF / 500) * 5 + frame * 0.001;
    let yOffset2 = (y2 + WORLD_HALF / 500) * 5 + frame * 0.001;
    let amp2 = pitch * 0.5 + 1;
    let noiseValue2 = 1 * (map(noise(xOffset2, yOffset2), 0, 1, -1, 1) * amp2) ** 2;

    let currentZ2 = posArray2[i + 2];
    let targetZ2 = noiseValue2;
    posArray2[i + 2] += (targetZ2 - currentZ2) * dampingFactor;
  }
  ring.geometry.attributes.position.needsUpdate = true;
}

function ringDown(ring) {
  const dampingFactor = 0.1; // control the speed of the transition

  let posArray2 = ring.geometry.attributes.position.array;
  for (let i = 0; i < posArray2.length; i += 3) {
    let x2 = posArray2[i + 0];
    let y2 = posArray2[i + 1];

    let xOffset2 = (x2 + WORLD_HALF / 500) * 5 + frame * 0.01;
    let yOffset2 = (y2 + WORLD_HALF / 500) * 5 + frame * 0.01;
    let amp2 = volume * 10 + 1;
    let noiseValue2 = -1 * (map(noise(xOffset2, yOffset2), 0, 1, -1, 1) * amp2) ** 2;

    let currentZ2 = posArray2[i + 2];
    let targetZ2 = noiseValue2;
    posArray2[i + 2] += (targetZ2 - currentZ2) * dampingFactor;
  }
  ring.geometry.attributes.position.needsUpdate = true;
}


function loadOBJ(filepath) {
  // load .obj file
  const loader = new OBJLoader();

  loader.load(
    // resource URL
    filepath,
    // onLoad callback

    // Here the loaded data is assumed to be an object
    function (obj) {
      // Add the loaded object to the scene
      //scene.add(obj); 
      //return obj;
      petalObj = obj;
      constructObjects(obj);

    },

    // onProgress callback
    function (xhr) {
      console.log((xhr.loaded / xhr.total * 100) + '% loaded');
    },

    // onError callback
    function (err) {
      console.error('An error happened');
    }
  );
}

function constructObjects(obj) {
  petalObj = obj;
  for (let i = 0; i < 30; i++) {
    let cPetal = new Petal(petalObj)
      .setPosition(random(-2, 2), 8, random(-2, 2))
      .setVelocity(random(-0.01, 0.01), random(-0.05, 0), random(-0.01, 0.01))
      .setRotationVelocity(random(-0.02, 0.02), random(-0.02, 0.02), random(-0.02, 0.02))
      .setScale(random(0.5, 1));
    petals.push(cPetal);
  }

}

function getRing(innerSet, outerSet) {
  const geometry = new THREE.RingGeometry(innerSet, outerSet, 128, 10);

  // Load a texture
  const textureLoader = new THREE.TextureLoader();
  const texture = textureLoader.load('assets/background/floor.jpeg');
  let material = new THREE.MeshPhongMaterial({
    color: 0xc0c0c0,
    // wireframe: true,
    //envMap: textureCube,
    map: texture,
    side: THREE.DoubleSide
  });
  const mesh = new THREE.Mesh(geometry, material);
  //mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);
  return mesh;
}

function getCeiling() {
  const points = [];
  for (let i = 0; i < 8; i++) {
    points.push(new THREE.Vector3(Math.sin(i * 0.25) * (WORLD_HALF / 2.1) + WORLD_HALF / 8, -i * WORLD_HALF / 10 + WORLD_HALF * 1, (i - 5) * WORLD_HALF / 3));
  }
  const geometry = new THREE.LatheGeometry(points, 8);

  // Load a texture
  const textureLoader = new THREE.TextureLoader();
  const texture = textureLoader.load('assets/background/floor.jpeg'); // Replace with the path to your image

  // Apply the texture to the material
  const material = new THREE.MeshBasicMaterial({ map: texture });

  const lathe = new THREE.Mesh(geometry, material);
  scene.add(lathe);

  return lathe;
}


function getRoom() {
  const geometry = new BoxLineGeometry(6, 6, 6, 10, 10, 10).translate(0, 3, 0);
  const materials = new THREE.LineBasicMaterial({
    color: 0xbcbcbc,
    transparent: true,
    opacity: 0.5,
  });
  const mesh = new THREE.LineSegments(geometry, materials);
  return mesh;
}

function getBox(height) {
  let geometry = new THREE.BoxGeometry(1, height, 1);

  // // Load a texture
  // const textureLoader = new THREE.TextureLoader();
  // const texture = textureLoader.load(fileName);

  const material = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.2,
    metalness: 0.0,
    flatshading: true,
    // map: texture
  });
  let mesh = new THREE.Mesh(geometry, material);
  scene.add(mesh);
  return mesh;
}


class Light {
  constructor() {
    this.pos = createVector();
    this.vel = createVector();
    this.acc = createVector();
    this.scl = createVector(1, 1, 1);
    this.mass = this.scl.x * this.scl.y * this.scl.z;
    this.rot = createVector();
    this.rotVel = createVector();
    this.rotAcc = createVector();

    this.mesh = getSphere();
    this.light = getLight();
    this.mesh.scale.set(40, 40, 40);
    this.intensity = 5
    this.group = new THREE.Group();
    this.group.add(this.mesh);
    this.group.add(this.light);

    scene.add(this.group);
  }
  setPosition(x, y, z) {
    this.pos = createVector(x, y, z);
    return this;
  }
  setVelocity(x, y, z) {
    this.vel = createVector(x, y, z);
    return this;
  }
  setRotationAngle(x, y, z) {
    this.rot = createVector(x, y, z);
    return this;
  }
  setRotationVelocity(x, y, z) {
    this.rotVel = createVector(x, y, z);
    return this;
  }
  setScale(w, h = w, d = w) {
    const minScale = 0.01;
    if (w < minScale) w = minScale;
    if (h < minScale) h = minScale;
    if (d < minScale) d = minScale;
    this.scl = createVector(w, h, d);
    this.mass = this.scl.x * this.scl.y * this.scl.z;
    return this;
  }
  move() {
    let freq = frame * 0.01; // also angle
    let radialDistance = 40;
    this.pos.x = cos(freq) * radialDistance;
    this.pos.z = sin(freq) * radialDistance;
  }
  update() {
    this.group.position.set(this.pos.x, this.pos.y, this.pos.z);
    this.group.rotation.set(this.rot.x, this.rot.y, this.rot.z);
    this.group.scale.set(this.scl.x, this.scl.y, this.scl.z);
  }
}

class Petal {
  constructor(object) {
    this.pos = createVector();
    this.vel = createVector();
    this.acc = createVector();

    this.scl = createVector(1, 1, 1);
    this.mass = this.scl.x * this.scl.y * this.scl.z;
    this.rot = createVector();
    this.rotVel = createVector();
    this.rotAcc = createVector();

    this.lifespan = 1.0;
    this.lifeReduction = random(0.001, 0.02);
    this.isDone = false;

    this.group = object.clone();
    for (let child of this.group.children) {
      //child.material = new THREE.MeshBasicMaterial();
      child.material = new THREE.MeshPhongMaterial();
      child.material.color.r = 1;
      child.material.color.g = 0;
      child.material.color.b = 0;
    }

    scene.add(this.group);
  }
  setPosition(x, y, z) {
    this.pos = createVector(x, y, z);
    return this;
  }
  setVelocity(x, y, z) {
    this.vel = createVector(x, y, z);
    return this;
  }
  setRotationAngle(x, y, z) {
    this.rot = createVector(x, y, z);
    return this;
  }
  setRotationVelocity(x, y, z) {
    this.rotVel = createVector(x, y, z);
    return this;
  }
  setScale(w, h = w, d = w) {
    const minScale = 0.01;
    if (w < minScale) w = minScale;
    if (h < minScale) h = minScale;
    if (d < minScale) d = minScale;
    this.scl = createVector(w, h, d);
    this.mass = this.scl.x * this.scl.y * this.scl.z;
    return this;
  }
  move() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.mult(0);
  }
  rotate() {
    this.rotVel.add(this.rotAcc);
    this.rot.add(this.rotVel);
    this.rotAcc.mult(0);
  }
  age() {
    this.lifespan -= this.lifeReduction;
    if (this.lifespan <= 0) {
      this.lifespan = 0;
      this.isDone = true;
    }
  }
  applyForce(f) {
    let force = f.copy();
    force.div(this.mass);
    this.acc.add(force);
  }
  update() {
    this.group.position.set(this.pos.x, this.pos.y, this.pos.z);
    this.group.rotation.set(this.rot.x, this.rot.y, this.rot.z);

    let newScale = p5.Vector.mult(this.scl, this.lifespan);
    this.group.scale.set(newScale.x, newScale.y, newScale.z);
  }
}
