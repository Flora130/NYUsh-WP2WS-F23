const params = {
    drawCount: 0,
    particleColor: 0xFFFFFF,
    petals: 0,
    scene_children: 0
    //
};


let room;
let petals = [];
let petalObj;
const raycaster = new THREE.Raycaster();
const mouse = new THREE.Vector2(); // check the event listener at the bottom 

let cubes = [];
let cubes1 = [];
let cubes2 = [];

const WORLD_HALF = 15;
let plane;
let ring1, ring2, ring3;
let particles = []
let stones = []
let lights = []
let pole;
let ceiling;

function preload() {
    soundFormats('mp3', 'ogg');
    mySound = loadSound('assets/Drum.mp3');
    mySound1 = loadSound('assets/luo.mp3');
    mySound2 = loadSound('assets/bang.mp3')
}

function setupThree() {

    loadOBJ("assets/petal.obj");

    camera.position.x = 20;
    camera.position.y = WORLD_HALF / 2;
    camera.position.z = 20;
    camera.rotation.y = PI / 2
    controls.update();

    for (let i = 0; i < 20; i++) {
        let x = cos(radians(18 * i)) * (WORLD_HALF / 2.5);
        let z = sin(radians(18 * i)) * (WORLD_HALF / 2.5);
        let x1 = cos(radians(18 * i)) * (WORLD_HALF / 3);
        let z1 = sin(radians(18 * i)) * (WORLD_HALF / 3);
        let x2 = cos(radians(18 * i)) * (WORLD_HALF / 5);
        let z2 = sin(radians(18 * i)) * (WORLD_HALF / 5);
        let tCube = new Cube()
            .setPosition(x, WORLD_HALF / 2, z)
            .setVelocity(0, 0, 0)
            .setRotationVelocity(random(-0.01, 0.01), random(-0.01, 0.01), random(-0.01, 0.01))
            .setScale(0.18, random(0.1, 0.25), random(0.1, 0.25));
        let tCube1 = new Cube()
            .setPosition(x1, WORLD_HALF / 1.5, z1)
            .setVelocity(0, 0, 0)
            .setRotationVelocity(random(-0.01, 0.01), random(-0.01, 0.01), random(-0.01, 0.01))
            .setScale(0.23, random(0.23, 0.25), random(0.23, 0.25));
        let tCube2 = new Cube()
            .setPosition(x2, WORLD_HALF / 1.2, z2)
            .setVelocity(0, 0, 0)
            .setRotationVelocity(random(-0.01, 0.01), random(-0.01, 0.01), random(-0.01, 0.01))
            .setScale(0.27, random(0.25, 0.3), random(0.25, 0.3));
        cubes.push(tCube);
        cubes1.push(tCube1);
        cubes2.push(tCube2)
    }


    ring2 = getRing(WORLD_HALF / 15, WORLD_HALF / 6);
    ring2.position.y = -WORLD_HALF / 20
    ring2.rotation.x = -PI / 2;

    ring3 = getRing(WORLD_HALF / 4, WORLD_HALF / 2);
    ring3.position.y = 0;
    ring3.rotation.x = -PI / 2;

    // enable shadow
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap; // default 

    const ambiLight = new THREE.AmbientLight(0xe0e0e0, 8);
    ambiLight.color.setRGB(0.5, 0.5, 0.5);
    scene.add(ambiLight);


    const stillLight = new Light();
    stillLight.setPosition(0, WORLD_HALF / 5, 0)
    lights.push(stillLight);
    // scene.add(stillLight);
    for (let l of lights) {
        l.update();
    }

    gui.add(params, "petals", 0, 5000).step(1).listen();
    gui.add(params, "scene_children", 0, 5000).step(1).listen();
    let folderAmbiLight = gui.addFolder("AmbientLight");
    folderAmbiLight.open();
    folderAmbiLight.add(ambiLight.color, "r", 0.0, 1.0);
    folderAmbiLight.add(ambiLight.color, "g", 0.0, 1.0);
    folderAmbiLight.add(ambiLight.color, "b", 0.0, 1.0);


    ceiling = getCeiling();
    scene.add(ceiling);
}



// let angle = 0;
function updateThree() {
    //updateAmbiLight(volume);

    ringUp(ring2);
    ringDown(ring3);


    // update the picking ray with the camera and mouse position
    raycaster.setFromCamera(mouse, camera);
    // calculate objects intersecting the picking ray
    const intersections = raycaster.intersectObjects(scene.children);


    for (let c of cubes) {
        c.intersect(intersections);
        c.move();
        c.rotate();
        c.update();
    }
    for (let c1 of cubes1) {
        c1.intersect(intersections);
        c1.move();
        c1.rotate();
        c1.update();
    }
    for (let c2 of cubes2) {
        c2.intersect(intersections);
        c2.move();
        c2.rotate();
        c2.update();
    }

    // to release mouse
    releaseMouse();

    // genreate stones
    for (let i = 0; i < 8; i++) {
        let xStone = cos(radians(45 * i)) * WORLD_HALF / 2;
        let zStone = sin(radians(45 * i)) * WORLD_HALF / 2;
        stones.push(new Stone(xStone, 0, zStone, WORLD_HALF / 200))

    }
    for (let s of stones) {
        // s.move();
        s.update();
    }

    // update the objects
    for (let p of petals) {
        p.move();
        p.rotate();
        p.update();
        p.age();
    }

    // // remove the cubes that are done
    for (let i = 0; i < petals.length; i++) {
        let p = petals[i];
        if (p.isDone) {
            scene.remove(p.mesh);
            petals.splice(i, 1);
            i--;
        }
    }

    // update the GUI
    params.petals = petals.length;
    params.scene_children = scene.children.length;
    window.addEventListener('keydown', onKeyDown);



}


function ringUp(ring) {
    const dampingFactor = 0.05; // control the speed of the transition

    let posArray2 = ring.geometry.attributes.position.array;
    for (let i = 0; i < posArray2.length; i += 3) {
        let x2 = posArray2[i + 0];
        let y2 = posArray2[i + 1];

        let xOffset2 = (x2 + WORLD_HALF / 500) * 5 + frame * 0.001;
        let yOffset2 = (y2 + WORLD_HALF / 500) * 5 + frame * 0.001;
        let amp2 = pitch * 0.1 + 1;
        let noiseValue2 = 1 * (map(noise(xOffset2, yOffset2), 0, 1, -1, 1) * amp2) ** 2;

        let currentZ2 = posArray2[i + 2];
        let targetZ2 = noiseValue2;
        posArray2[i + 2] += (targetZ2 - currentZ2) * dampingFactor;
    }
    ring.geometry.attributes.position.needsUpdate = true;
}

function ringDown(ring) {
    const dampingFactor = 0.1; // control the speed of the transition

    let posArray2 = ring.geometry.attributes.position.array;
    for (let i = 0; i < posArray2.length; i += 3) {
        let x2 = posArray2[i + 0];
        let y2 = posArray2[i + 1];

        let xOffset2 = (x2 + WORLD_HALF / 500) * 5 + frame * 0.01;
        let yOffset2 = (y2 + WORLD_HALF / 500) * 5 + frame * 0.01;
        let amp2 = volume * 80 + 1;
        let noiseValue2 = -1 * (map(noise(xOffset2, yOffset2), 0, 1, -1, 1) * amp2) ** 2;

        let currentZ2 = posArray2[i + 2];
        let targetZ2 = noiseValue2;
        posArray2[i + 2] += (targetZ2 - currentZ2) * dampingFactor;
    }
    ring.geometry.attributes.position.needsUpdate = true;
}

function updateCamera() {
    camera.updateProjectionMatrix();
}

function getRing(innerSet, outerSet) {
    const geometry = new THREE.RingGeometry(innerSet, outerSet, 128, 10);
    let material = new THREE.MeshPhongMaterial({
        color: 0xc0c0c0,
        // wireframe: true,
        //envMap: textureCube,
        side: THREE.DoubleSide
    });
    const mesh = new THREE.Mesh(geometry, material);
    //mesh.castShadow = true;
    mesh.receiveShadow = true;
    scene.add(mesh);
    return mesh;
}

function getSphere() {
    const geometry = new THREE.SphereGeometry(WORLD_HALF / 1500, 16, 16);
    const material = new THREE.MeshBasicMaterial({
        color: 0xe0e0e0,
    });
    const mesh = new THREE.Mesh(geometry, material);
    return mesh;
}


function getBox() {
    let geometry = new THREE.BoxGeometry(1, 1, 1);
    let material = new THREE.MeshBasicMaterial({
        wireframe: true
    });
    let mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);
    return mesh;
}

function getLight() {
    const light = new THREE.SpotLight(0xCC0066, WORLD_HALF, WORLD_HALF * 2, PI / 2, 0.5, 0.1); // (color, intensity, distance (0=infinite), angle, penumbra, decay)
    light.castShadow = true; // default false
    // can't manipulate the mapSize in realtime.
    light.shadow.mapSize.width = 1024; // default
    light.shadow.mapSize.height = 1024; // default
    return light;
}

function getCeiling() {
    const points = [];
    for (let i = 0; i < 8; i++) {
        points.push(new THREE.Vector3(Math.sin(i * 0.25) * (WORLD_HALF / 2.1) + WORLD_HALF / 8, -i * WORLD_HALF / 10 + WORLD_HALF * 1, (i - 5) * WORLD_HALF / 3));
    }
    const geometry = new THREE.LatheGeometry(points, 8);
    const material = new THREE.MeshLambertMaterial({
        color: 0xfc0c0c0
        //wireframe: true
    });
    const lathe = new THREE.Mesh(geometry, material);
    scene.add(lathe);
    return lathe;
}


function getStone() {
    const length = WORLD_HALF / 2, width = WORLD_HALF * 5;

    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.lineTo(0, width);
    shape.lineTo(length, width);
    shape.lineTo(length, 0);
    shape.lineTo(0, 0);

    const extrudeSettings = {
        steps: 2,
        depth: 16,
        bevelEnabled: true,
        bevelThickness: 3,
        bevelSize: 1,
        bevelOffset: 0,
        bevelSegments: 1
    };

    const geometry = new THREE.ExtrudeGeometry(shape, extrudeSettings);
    const material = new THREE.MeshLambertMaterial({
        color: 0xffffff,
        // wireframe: true,
        //envMap: textureCube,
        side: THREE.DoubleSide
    });
    const mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);

    return mesh;
}

function loadOBJ(filepath) {
    // load .obj file
    const loader = new OBJLoader();

    loader.load(
        filepath,
        // onLoad callback
        // Here the loaded data is assumed to be an object
        function (obj) {
            // Add the loaded object to the scene
            //scene.add(obj); 
            petalObj = obj;
            constructObjects(obj);
        },
        // onProgress callback
        function (xhr) {
            console.log((xhr.loaded / xhr.total * 100) + '% loaded');
        },
        // onError callback
        function (err) {
            console.error('An error happened');
        }
    );
}

function onKeyDown(event) {
    if (event.code === 'Space') {
        constructObjects(petalObj);

    }
}

function constructObjects(obj) {
    petalObj = obj;
    for (let i = 0; i < 2; i++) {
        let cPetal = new Petal(petalObj)
            .setPosition(0, 6, 0)
            .setVelocity(random(-0.01, 0.01), random(-0.02, 0), random(-0.01, 0.01))
            .setRotationVelocity(random(-0.02, 0.02), random(-0.02, 0.02), random(-0.02, 0.02))
            .setScale(random(1, 1.5));
        petals.push(cPetal);
    }

}


class Light {
    constructor() {
        this.pos = createVector();
        this.vel = createVector();
        this.acc = createVector();
        this.scl = createVector(1, 1, 1);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        this.rot = createVector();
        this.rotVel = createVector();
        this.rotAcc = createVector();

        this.mesh = getSphere();
        this.light = getLight();
        this.mesh.scale.set(20, 20, 20);
        this.intensity = 5
        this.group = new THREE.Group();
        this.group.add(this.mesh);
        this.group.add(this.light);

        scene.add(this.group);
    }
    setPosition(x, y, z) {
        this.pos = createVector(x, y, z);
        return this;
    }
    setVelocity(x, y, z) {
        this.vel = createVector(x, y, z);
        return this;
    }
    setRotationAngle(x, y, z) {
        this.rot = createVector(x, y, z);
        return this;
    }
    setRotationVelocity(x, y, z) {
        this.rotVel = createVector(x, y, z);
        return this;
    }
    setScale(w, h = w, d = w) {
        const minScale = 0.01;
        if (w < minScale) w = minScale;
        if (h < minScale) h = minScale;
        if (d < minScale) d = minScale;
        this.scl = createVector(w, h, d);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        return this;
    }
    move() {
        let freq = frame * 0.01; // also angle
        let radialDistance = 40;
        this.pos.x = cos(freq) * radialDistance;
        this.pos.z = sin(freq) * radialDistance;
    }
    update() {
        this.group.position.set(this.pos.x, this.pos.y, this.pos.z);
        this.group.rotation.set(this.rot.x, this.rot.y, this.rot.z);
        this.group.scale.set(this.scl.x, this.scl.y, this.scl.z);
    }
}

class Stone {
    constructor(x, y, z, size) {
        this.pos = createVector(x, y, z);
        this.mass = 1;
        this.size = size;
        this.lifespan = 1.00;
        this.lifeReduction = random(0.01, 0.02);
        this.isDone = false;
        this.mesh = getStone();
        this.mesh.scale.set(this.size, this.size, this.size);
        // this.angle = i
    }
    slowDown() {
        this.vel.mult(0.1);
    }
    update() {
        this.mesh.position.x = this.pos.x
        this.mesh.position.y = this.pos.y
        this.mesh.position.z = this.pos.z
    }

}

class Cube {
    constructor() {
        this.pos = createVector();
        this.vel = createVector();
        this.acc = createVector();
        this.scl = createVector(1, 1, 1);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        this.rot = createVector();
        this.rotVel = createVector();
        this.rotAcc = createVector();
        this.isSelected = false;
        this.mesh = getBox();
    }
    setPosition(x, y, z) {
        this.pos = createVector(x, y, z);
        return this;
    }
    setVelocity(x, y, z) {
        this.vel = createVector(x, y, z);
        return this;
    }
    setRotationAngle(x, y, z) {
        this.rot = createVector(x, y, z);
        return this;
    }
    setRotationVelocity(x, y, z) {
        this.rotVel = createVector(x, y, z);
        return this;
    }
    setScale(w, h = w, d = w) {
        const minScale = 0.01;
        if (w < minScale) w = minScale;
        if (h < minScale) h = minScale;
        if (d < minScale) d = minScale;
        this.scl = createVector(w, h, d);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        return this;
    }
    move() {
        this.vel.add(this.acc);
        this.pos.add(this.vel);
        this.acc.mult(0);
    }
    rotate() {
        this.rotVel.add(this.rotAcc);
        this.rot.add(this.rotVel);
        this.rotAcc.mult(0);
    }
    applyForce(f) {
        let force = f.copy();
        force.div(this.mass);
        this.acc.add(force);
    }
    intersect(intersections) {
        let isIntersected = false;
        // if you only want to select the first (closest) one.
        if (intersections.length > 0) {
            if (this.mesh.uuid === intersections[0].object.uuid) {
                isIntersected = true;
            }
        }
    }
    update() {
        this.mesh.position.set(this.pos.x, this.pos.y, this.pos.z);
        this.mesh.rotation.set(this.rot.x, this.rot.y, this.rot.z);
        this.mesh.scale.set(this.scl.x, this.scl.y, this.scl.z);
    }
}

class Petal {
    constructor(object) {
        this.pos = createVector();
        this.vel = createVector();
        this.acc = createVector();

        this.scl = createVector(1, 1, 1);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        this.rot = createVector();
        this.rotVel = createVector();
        this.rotAcc = createVector();

        this.lifespan = 1.0;
        this.lifeReduction = random(0.005, 0.010);
        this.isDone = false;

        this.group = object.clone();
        for (let child of this.group.children) {
            //child.material = new THREE.MeshBasicMaterial();
            child.material = new THREE.MeshPhongMaterial();
            child.material.color.r = 1;
            child.material.color.g = 0;
            child.material.color.b = 0;
        }

        scene.add(this.group);
    }
    setPosition(x, y, z) {
        this.pos = createVector(x, y, z);
        return this;
    }
    setVelocity(x, y, z) {
        this.vel = createVector(x, y, z);
        return this;
    }
    setRotationAngle(x, y, z) {
        this.rot = createVector(x, y, z);
        return this;
    }
    setRotationVelocity(x, y, z) {
        this.rotVel = createVector(x, y, z);
        return this;
    }
    setScale(w, h = w, d = w) {
        const minScale = 0.01;
        if (w < minScale) w = minScale;
        if (h < minScale) h = minScale;
        if (d < minScale) d = minScale;
        this.scl = createVector(w, h, d);
        this.mass = this.scl.x * this.scl.y * this.scl.z;
        return this;
    }
    move() {
        this.vel.add(this.acc);
        this.pos.add(this.vel);
        this.acc.mult(0);
    }
    rotate() {
        this.rotVel.add(this.rotAcc);
        this.rot.add(this.rotVel);
        this.rotAcc.mult(0);
    }
    age() {
        this.lifespan -= this.lifeReduction;
        if (this.lifespan <= 0) {
            this.lifespan = 0;
            this.isDone = true;
        }
    }
    applyForce(f) {
        let force = f.copy();
        force.div(this.mass);
        this.acc.add(force);
    }
    update() {
        this.group.position.set(this.pos.x, this.pos.y, this.pos.z);
        this.group.rotation.set(this.rot.x, this.rot.y, this.rot.z);

        let newScale = p5.Vector.mult(this.scl, this.lifespan);
        this.group.scale.set(newScale.x, newScale.y, newScale.z);
    }
}


// event listeners
window.addEventListener("resize", onWindowResize);
window.addEventListener('click', onClick);

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}


function onClick(event) {
    // calculate mouse position in normalized device coordinates
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    const intersections = raycaster.intersectObjects(scene.children);
    if (intersections.length > 0) {
        const clickedObject = intersections[0].object;
        const clickedCube = cubes.concat(cubes1).concat(cubes2).find(cube => cube.mesh === clickedObject);
        if (clickedCube) {
            if (clickedCube.mesh.scale.x < 0.2) {
                if (mySound.isLoaded()) {
                    mySound.play();
                }
            } if (0.22 < clickedCube.mesh.scale.x && clickedCube.mesh.scale.x < 0.24) {
                if (mySound1.isLoaded()) {
                    mySound1.play();
                }
            } if (clickedCube.mesh.scale.x > 0.25) {
                if (mySound2.isLoaded()) {
                    mySound2.play();
                }
            }
            // Remove clicked cube from the array
            const cubeArray = (clickedCube.mesh.scale.x < 1) ? cubes1 : cubes;
            const index = cubeArray.indexOf(clickedCube);
            if (index !== -1) {
                cubeArray.splice(index, 1);
            }
            scene.remove(clickedCube.mesh);
        }
    }
}

function releaseMouse() {
    // put the position out of the renderer with an arbitrary value
    mouse.set(-10000, -10000);
}

