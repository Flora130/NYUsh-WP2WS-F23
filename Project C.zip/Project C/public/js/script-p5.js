let beat, song;
let amp;
let volume = 0
let fft;
let pitch = 0;

let sounds = [];
let soundFilenames = [
  // smaller
  "H1.mp3",
  "H2.mp3",
  "H3.mp3",
  "H4.mp3",
  "H5.mp3",
  "H6.mp3",
  "H7.mp3",
  "H8.mp3",
  "H9.mp3",
  "H10.mp3",
  "H11.mp3",
  "H12.mp3",
  // still small
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  "Bell.mp3",
  // big!
  "ORC1.mp3",
  "ORC2.mp3",
  "ORC3.mp3",
  "ORC4.mp3",
  "ORC5.mp3",
  "ORC6.mp3",
  "ORC7.mp3",
  "ORC8.mp3",
]

function preload() {
  beat = loadSound("assets/bg.mp3");
  song = loadSound("assets/Drum.mp3");

  for (let i = 0; i < soundFilenames.length; i++) {
    let filepath = "assets/" + soundFilenames[i];
    sounds.push(loadSound(filepath));
  }
}

function setup() {
  let canvas = createCanvas(640, 480);
  canvas.parent("container-p5");
  canvas.hide();

  amp = new p5.Amplitude();

  fft = new p5.FFT();
  fft.setInput(amp);

  initThree(); // ***
}

function draw() {
  volume = amp ? amp.getLevel() : 0;
  pitch = getPitch();
}

function keyPressed() {
  if (key == " ") {
    constructObjects(petalObj);
  }
  else if (key == "s") {
    if (song.isPlaying()) {
      song.stop();
    } else {
      song.play();
    }
  }
  const keyNumber = parseInt(key);
  if (keyNumber >= 0 && keyNumber < 9) {
    sendSocket({ num: keyNumber });
  }
}

function playSound(index) {
  //beat.rate(map(num, 0, 9, 0.1, 2));
  sounds[index].play();
  constructObjects(petalObj);
}

function getPitch() {
  let spectrum = fft.analyze();
  let peakIndex = indexOfMax(spectrum);

  // 将频谱中的索引映射到相应的音高范围
  let pitch = map(peakIndex, 0, spectrum.length, 0, 1000); // 调整范围根据需要

  return pitch;
}

// 获取数组中最大值的索引
function indexOfMax(arr) {
  if (arr.length === 0) {
    return -1;
  }

  let max = arr[0];
  let maxIndex = 0;

  for (let i = 1; i < arr.length; i++) {
    if (arr[i] > max) {
      maxIndex = i;
      max = arr[i];
    }
  }

  return maxIndex;
}